package com.pack.model;

public class Acc {
	
	
	String AccNumber,AccName,AccBranch,AccCurrency,AccBalance;
	int CorpID;
	public String getAccNumber() {
		return AccNumber;
	}
	public void setAccNumber(String accNumber) {
		AccNumber = accNumber;
	}
	public String getAccName() {
		return AccName;
	}
	public void setAccName(String accName) {
		AccName = accName;
	}
	public String getAccBranch() {
		return AccBranch;
	}
	public void setAccBranch(String accBranch) {
		AccBranch = accBranch;
	}
	public String getAccCurrency() {
		return AccCurrency;
	}
	public void setAccCurrency(String accCurrency) {
		AccCurrency = accCurrency;
	}
	public String getAccBalance() {
		return AccBalance;
	}
	public void setAccBalance(String accBalance) {
		AccBalance = accBalance;
	}
	
	public int getCorpID() {
		return CorpID;
	}
	public void setCorpID(int corpID) {
		CorpID = corpID;
	}
	

}
