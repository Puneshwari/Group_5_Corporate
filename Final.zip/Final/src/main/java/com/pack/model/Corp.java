package com.pack.model;

public class Corp {
	
	private String CorpName,CorpAddress,CorpPhone;
	public int CorpID;
	public String getCorpName() {
		return CorpName;
	}
	public void setCorpName(String corpName) {
		CorpName = corpName;
	}
	public String getCorpAddress() {
		return CorpAddress;
	}
	public void setCorpAddress(String corpAddress) {
		CorpAddress = corpAddress;
	}
	public String getCorpPhone() {
		return CorpPhone;
	}
	public void setCorpPhone(String corpPhone) {
		CorpPhone = corpPhone;
	}
	public int getCorpID() {
		return CorpID;
	}
	public void setCorpID(int corpID) {
		CorpID = corpID;
	}
	
	
	
	

}
